<?php

return [
    [
        'name' => 'System',
        'flag' => 'core.system',
    ],
];
